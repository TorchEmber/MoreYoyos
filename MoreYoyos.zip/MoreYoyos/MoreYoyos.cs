using Terraria.ModLoader;

namespace MoreYoyos
{
	class MoreYoyos : Mod
	{
		public MoreYoyos()
		{
		}
	}
}
